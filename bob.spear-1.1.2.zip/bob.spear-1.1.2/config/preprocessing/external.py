#!/usr/bin/env python

import spear

preprocessor = spear.preprocessing.External

win_length_ms = 20
win_shift_ms = 10


