Elie Khoury <Elie.Khoury@idiap.ch>
Those protocols are tested internally at Idiap. 
If you need more details about them, please contact us.
 
